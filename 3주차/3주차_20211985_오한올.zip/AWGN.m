function r = AWGN(y,SNR)
    L=length(y);
    z=sqrt(0.5*10^(-SNR/10))*(randn(1,L)+1j*randn(1,L));
    % randn 에서 n 은 normal. 정규분포. AWGN을 모델링하면 정규분포를 따름
    r=y+z;
    

end