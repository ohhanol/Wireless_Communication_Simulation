function EQ_out=fading(y,SNR)

h=sqrt(0.5)*randn(1,length(y))+1j*randn(1,length(y));   % 페이딩 채널 계수 h(n) 신호 각각에 곱해주려고 h도 똑같이 N/2개 만듦
z=sqrt(0.5*10^(-SNR/10))*(randn(1,length(y))+1j*randn(1,length(y)));    % noise

r=h.*y+z;   % 수신신호 r
EQ_out=r./h;    % 이퀄라이저 출력 (페이딩 채널 보상)
end