function y = randint(N, M)
% 0.5보다 크면 1, 0.5보다 작으면 0으로 바꿔서 Binary Data(0 or 1)을 출력하는 함수
x=rand(N,M);
y=zeros(N,M);

for n=1:N
    for m=1:M
        if x(n,m)>0.5
            y(n,m)=1;
        else
            y(n,m)=0;
        end
    end
end

end