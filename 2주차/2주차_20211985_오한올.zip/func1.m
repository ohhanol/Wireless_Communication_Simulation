%% 과제 1
% 임의의 벡터를 입력받아 홀수번째 원소로 다시 벡터를 만들어 출력하는 함수

function y=func1(x)
y=x(1:2:end);
end