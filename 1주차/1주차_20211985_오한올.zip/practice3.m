% 1부터 20까지 짝수끼리 더하기

clear; clc;

fact=0;
for k=2:2:20
    fact=fact+k;
end

disp(fact);